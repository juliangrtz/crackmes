Rew1nd
by: expl0itr

Arch: x86
Platform: Windows

This crackme was programmed with .NET 4.8 but ported to real x86 native code. Brace yourself for a challenge!
Patching is not only allowed but heavily encouraged due to the strong obfuscation.